#pragma once
class Rect : public Shape {
protected:
	virtual void draw();
};