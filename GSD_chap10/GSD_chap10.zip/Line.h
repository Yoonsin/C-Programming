#pragma once
class Line : public Shape {
protected:
	virtual void draw();
};