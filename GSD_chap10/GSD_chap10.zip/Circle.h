#pragma once
class Circle : public Shape {
protected:
	virtual void draw();
};